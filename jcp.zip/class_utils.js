class StringBuilder{
    constructor(val=''){
        this.value=val
        this.append=(str)=>this.value+=str+'\n'
        this.toString=()=>this.value
    }
}
module.exports= class ClassUtils {
	EMPTY_GENERICS = '';

	this.hasGenerics=( className) =>{
		if(!className.includes("<")) {
			return false;
		}
		if(!className.includes(">")) {
			return false;
		}
		return true;
	}

	this.getGenericTypes=(className='')=> {
		if(!hasGenerics(className)) {
			return EMPTY_GENERICS;
		}
		var genericClasses = className.substring(className.indexOf('<') + 1, className.lastIndexOf('>'));
		return genericClasses.split(";");
	}

	this. appendPackageSpecifier=(/*StringBuilder*/ result, /*SignatureParser.PackageSpecifierContext*/ context)=> {
		if(context.identifier() == null) {
			return;
		}
		result.append(context.identifier().getText()+'\n/');

		if(context.packageSpecifier() == null) {
			return;
		}
		for(let i = 0; i < context.packageSpecifier().size(); i++) {
			appendPackageSpecifier(result, context.packageSpecifier(i));
		}
	}

	this.getQualifiedSimpleClassName=(/*SignatureParser.ClassTypeSignatureContext*/ context)=> {
		var result = new StringBuilder()
		appendPackageSpecifier(result, context.packageSpecifier());
		result.append(context.simpleClassTypeSignature().identifier().getText());
		return result.toString();
	}

	this. isSameType=(/*final MethodDescriptor*/ expectedType, /*final MethodSignature*/ actualType)=> {
		if(actualType.getTotalMethodArguments() != expectedType.getTotalMethodParameters()) {
			return false;
		}

		var match = true;
		for(var i = 0; i < actualType.getTotalMethodArguments(); i++) {
			var /*final DescriptorParser.FieldTypeContext*/ expectedTypeSignature = expectedType.getMethodParameter(i);
			var /*final SignatureParser.JavaTypeSignatureContext*/ actualTypeSignature = actualType.getMethodArgument(i);

			if(!ClassUtils.isSameType(expectedTypeSignature, actualTypeSignature)) {
				match = false;
				break;
			}
		}

		if(!match) {
			return false;
		}
		if(expectedType.isVoidMethod() && actualType.isVoidMethod()) {
			return true;
		}
		if(expectedType.isVoidMethod() && !actualType.isVoidMethod()) {
			return false;
		}
		if(!expectedType.isVoidMethod() && actualType.isVoidMethod()) {
			return false;
		}
		var /*final DescriptorParser.ReturnDescriptorContext*/ expectedReturnTypeSignature = expectedType.getReturnDescriptor();
		var /*final SignatureParser.JavaTypeSignatureContext*/ actualReturnTypeSignature = actualType.getReturnType();

		return isSameType(expectedReturnTypeSignature.fieldType(), actualReturnTypeSignature);
	}

	
    this. isSameType=(/*final DescriptorParser.FieldTypeContext*/ expectedType,/* final SignatureParser.JavaTypeSignatureContext*/ actualType)=> {
		if(expectedType.BaseType() != null) {
			if(actualType.BaseType() != null) {
				return expectedType.BaseType().getText().equals(actualType.BaseType().getText());
			}
			return false;
		}
		if(expectedType.objectType() != null) {
			if(actualType.referenceTypeSignature() != null && actualType.referenceTypeSignature().classTypeSignature() != null) {
				var actualObjectType = actualType.referenceTypeSignature().classTypeSignature().getText();
				if(actualObjectType.includes("<")) {
					actualObjectType = actualObjectType.substring(0, actualObjectType.indexOf('<'));
				} else {
					actualObjectType = actualObjectType.substring(0, actualObjectType.indexOf(';'));
				}
				return actualObjectType==("L" + expectedType.objectType().identifier().getText());
			}
			return false;
		}
		if(expectedType.arrayType() != null) {
			if(actualType.referenceTypeSignature() != null && actualType.referenceTypeSignature().arrayTypeSignature() != null) {
				var/*DescriptorParser.ArrayTypeContext*/ expectedArrayType = expectedType.arrayType();
				var/*SignatureParser.ArrayTypeSignatureContext*/ actualArrayType = actualType.referenceTypeSignature().arrayTypeSignature();
				while(expectedArrayType != null) {
					if(expectedArrayType.fieldType().arrayType() != null) {
						if(actualArrayType.javaTypeSignature().referenceTypeSignature() == null) {
							return false;
						}
						if(actualArrayType.javaTypeSignature().referenceTypeSignature().arrayTypeSignature() == null) {
							return false;
						}
						expectedArrayType = expectedArrayType.fieldType().arrayType();
						actualArrayType = actualArrayType.javaTypeSignature().referenceTypeSignature().arrayTypeSignature();
						continue;
					} else if(expectedArrayType.fieldType().objectType() != null) {
						if(actualArrayType.javaTypeSignature().referenceTypeSignature() == null) {
							return false;
						}
						if(actualArrayType.javaTypeSignature().referenceTypeSignature().classTypeSignature() == null) {
							return false;
						}
						var actualObjectType = actualArrayType.javaTypeSignature().referenceTypeSignature().classTypeSignature().getText();
						if(actualObjectType.includes("<")) {
							actualObjectType = actualObjectType.substring(0, actualObjectType.indexOf('<'));
						} else {
							actualObjectType = actualObjectType.substring(0, actualObjectType.indexOf(';'));
						}
						return actualObjectType.equals("L" + expectedArrayType.fieldType().objectType().identifier().getText());
					} else {
						if(actualArrayType.javaTypeSignature().BaseType() == null) {
							return false;
						}
						return expectedArrayType.fieldType().BaseType().getText().equals(actualArrayType.javaTypeSignature().BaseType().getText());
					}
				}
			}
			return false;
		}
		return false;
	}

	this.isArray=(name)=> {
		return name.startsWith("[");
	}

	this.getArrayDimensions=( name)=> {
		var totalDimensions = 0;
		for(var i = 0; i < name.length; i++) {
			if(name.[i] == '[') {
				totalDimensions++;
			}
		}
		return totalDimensions;
	}

	this.isPrimitive=(name) =>{
		return !name.startsWith("L") && !name.startsWith("[");
	}

	 isObject(String name) {
		return name.startsWith("L");
	}

	public static boolean isArrayOfPrimitives(String name) {
		if(!name.startsWith("[")) {
			return false;
		}
		for(int i = 1; i < name.length(); i++) {
			if(name.charAt(i) == '[') {
				continue;
			}
			return name.charAt(i) != 'L';
		}
		return false;
	}

	public static boolean isArrayOfObjects(String name) {
		if(!name.startsWith("[")) {
			return false;
		}
		for(int i = 1; i < name.length(); i++) {
			if(name.charAt(i) == '[') {
				continue;
			}
			return name.charAt(i) == 'L';
		}
		return false;
	}

	public static PrimitiveType getPrimitiveType(String name) {
		while(name.charAt(0) == '[') {
			name = name.substring(1);
		}
		return getPrimitiveType(name.charAt(0));
	}

	public static PrimitiveType getPrimitiveType(char c) {
		for(PrimitiveType primitiveType : PrimitiveType.values()) {
			if(c == primitiveType.getTerm()) {
				return primitiveType;
			}
		}
		return null;
	}

	static PrimitiveOrReferenceType getPrimitiveOrReferenceType(char c) {
		for(PrimitiveOrReferenceType primitiveOrRefType : PrimitiveOrReferenceType.values()) {
			if(c == primitiveOrRefType.getTerm()) {
				return primitiveOrRefType;
			}
		}
		return null;
	}

	public static String getReferenceClass(String name) {
		int offset = 0;

		switch(name.charAt(0)) {
		case '[':
			offset = 1;
			for(int i = 1; i < name.length(); i++) {
				if(name.charAt(i) == '[') {
					offset++;
					continue;
				}
				if(name.charAt(i) == 'L') {
					offset++;
					break;
				}
				return null;
			}
			break;
		case 'L':
			offset = 1;
			break;
		default:
			for(PrimitiveOrReferenceType typeOrRef : PrimitiveOrReferenceType.values()) {
				if(typeOrRef.getTerm() == name.charAt(0)) {
					return null;
				}
			}
			break;
		}

		if(name.endsWith(";")) {
			name = name.substring(offset);
			return name.substring(0, name.length() - 1);
		}
		return name.substring(offset);
	}
}
