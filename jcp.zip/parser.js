fs=require("fs")
//fs.renameSync(name,dest)
var {bufCopy, ClassAccessFlag, ConstantClass, FieldInfo, MethodInfo}=require('./utils')
var bytez=(fs.readFileSync(
    //"idk.class"
    "test/com/klonisPlugins/Manhunt/ManHunt.class"
    ))

function parseClass(bytez=Buffer.from('')){
  var SIGNATURE=0xCAFEBABE
  var offset=4
  if(bytez.readUInt32BE() ==SIGNATURE){
    console.log("its a class") 

    var minorv= bytez.readUInt16BE(offset)

    var majorv= bytez.readUInt16BE(offset+2)
    var cpoolcount= bytez.readUInt16BE(offset+4)
    offset+=6
    var cpoolbuf=bytez
    var cpool=[]
    for (let i = 1; i < cpoolcount; i++) {
            
            var type = cpoolbuf.readUInt8(offset);
            offset++
            switch (type) {
            case 1: //CONSTANT_Utf8
            var len=cpoolbuf.readUInt16BE(offset)
            cpool[i]=String(bufCopy(cpoolbuf,offset+2,offset+len+2))  
            //cpool[i] = String.fromCharCode()
                offset+=2+len
                
                break;
            case 3: //CONSTANT_Integer
                cpool[i] = cpoolbuf.readInt32BE(offset)
                offset+=4
                break;
            case 4: //CONSTANT_Float
                cpool[i] =cpoolbuf.readFloatBE(offset)
                offset+=4
                break;
            case 5: //CONSTANT_Long
                cpool[i] = cpoolbuf.readUIntBE(offset)
                offset+=8
                i++
                break;
            case 6: //CONSTANT_Double
                cpool[i] =cpoolbuf.readDoubleBE(offset)
                offset+=8
                i++;
                break;
            case 7: //CONSTANT_Class
            case 8: //CONSTANT_String
            case 16: //CONSTANT_MethodType
            case 19: //CONSTANT_Module_info
            case 20: //CONSTANT_Package_info
                cpool[i] = [type, cpoolbuf.readUInt16BE(offset)]
                offset+=2
                break;
            case 9: //CONSTANT_Fieldref
            case 10: //CONSTANT_Methodref
            case 11: //CONSTANT_InterfaceMethodref
            case 12: //CONSTANT_NameAndType
            case 17: //CONSTANT_Dynamic
            case 18: //CONSTANT_InvokeDynamic
                cpool[i] = [type,cpoolbuf.readUInt16BE(offset),cpoolbuf.readUInt16BE(offset+2)];
                offset+=4
                break;
            case 15: //CONSTANT_MethodHandle
                cpool[i] = [type, cpoolbuf.readInt8(offset), cpoolbuf.readInt16BE(offset+1)];
                offset+=3
                break;
            default:
                throw new Error("Unknown constant pool type: " + type);
            }
    }
    cpool=require('./something_fucking_horrific')(cpool,cpoolcount,majorv)
    var accessflags= bytez.readUInt16BE(offset)
    var classAccessFlags=[]
    //
    //console.log(offset)
    offset+=2
    for(var Enum in ClassAccessFlag.enums) {
      var classAccessFlag=ClassAccessFlag.enums[Enum]
       if((classAccessFlag & accessflags) == classAccessFlag) {
       classAccessFlags.push(classAccessFlag);
      }
  }
  var this_class=cpool[bytez.readUInt16BE(offset)]
  var super_class=cpool[bytez.readUInt16BE(offset+2)]
  console.log(" 0x"+offset.toString(16))
  var debugarea=bufCopy(bytez,offset,offset+100)
  var ipoolcount= bytez.readUInt16BE(offset+4)
  offset+=6
  var interfaces = [new ConstantClass()];
  interfaces.pop()
  for( var i = 0; i < ipoolcount; i++ ) {
        interfaces[i] = cpool[bytez.readUInt16BE(offset)];
        offset+=2
  }
  var fieldcount=bytez.readUInt16BE(offset)
  offset+=2
  var fields=[]
  for( let i = 0; i < fieldcount; i++ ) {
    fields[i] = new FieldInfo( cpoolbuf,offset, cpool );
    offset=fields[i].newOffset
}
var methodscount=bytez.readUInt16BE(offset)
offset+=2
var methods = []//new MethodInfo[input.readUnsignedShort()];
for( var i = 0; i < methodscount; i++ ) {
    methods[i] = new MethodInfo( bytez, cpool, offset );
    offset=methods[i].newOffset
}

  // var apoolcount= bytez.readUInt16BE(offset)
  // offset+=2
  // var attributes = [new ConstantClass()];
    METHODS=methods
    console.log(offset,ipoolcount,methods,cpool)
    return
  }
  console.log("not a class")
 
}
parseClass(bytez)
setTimeout(()=>{},1000000)