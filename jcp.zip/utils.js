var ReferenceKind =[
    'REF_NULL',
    'REF_GETFIELD',
    'REF_GETSTATIC',
    'REF_PUTFIELD',
    'REF_PUTSTATIC',
    'REF_INVOKEVIRTUAL',
    'REF_INVOKESTATIC',
    'REF_INVOKESPECIAL',
    'REF_NEWINVOKESPECIAL',
    'REF_INVOKEINTERFACE',
]
class ClassAccessFlag {
	
    static enums={

         PUBLIC:(0x0001),
         PRIVATE:(0x0002),
         PROTECTED:(0x0004),
         STATIC:(0x0008),
        
         FINAL:(0x0010),
         SUPER:(0x0020),

         INTERFACE:(0x0200),
         ABSTRACT:(0x0400),
        
         SYNTHETIC:(0x1000),
         ANNOTATION:(0x2000),
         ENUM:(0x4000),
    }
    
	constructor(mask) {
		this.mask = mask;
	}
}
class FieldsAccessFlag {
	
    static enums={

        PUBLIC:(0x0001),
        PRIVATE:(0x0002),
        PROTECTED:(0x0004),
        STATIC:(0x0008),
    
        FINAL:(0x0010),
        VOLATILE:(0x0040),
        TRANSIENT:(0x0080),
    
        SYNTHETIC:(0x1000),
        ENUM:(0x4000)
    }
    
	constructor(mask) {
		this.mask = mask;
	}
}

class MethodAccessFlag {
	
    static enums={

        PUBLIC:(0x0001),
        PRIVATE:(0x0002),
        PROTECTED:(0x0004),
        STATIC:(0x0008),
    
        FINAL:(0x0010),
        SYNCHRONIZED:(0x0020),
        BRIDGE:(0x0040),
        VARARGS:(0x0080),
        NATIVE:(0x0100),
        ABSTRACT:(0x0400),
        STRICT:(0x0800),
        SYNTHETIC:(0x1000),
    }
    
	constructor(mask) {
		this.mask = mask;
	}
}

class ConstantInvokeDynamic {

    constructor( bootstrapMethodIndex,  nameAndType) {
        this.bootstrapMethodIndex = bootstrapMethodIndex;
        this.nameAndType = nameAndType;
    }
}
class ConstantDynamic {

	constructor( bootstrapMethodIndex,  nameAndType) {
		this.bootstrapMethodIndex = bootstrapMethodIndex;
		this.nameAndType = nameAndType;
	}
}
class ConstantMethodType {

    constructor(descriptor) {
		this.descriptor = descriptor;
}
}
class ConstantNameAndType{
    constructor( name,  type){
        this.name = name;
        this.type = type;
    }
}
class ConstantMethodHandle {
//	private final ReferenceKind referenceKind;
//	private final ConstantRef reference;

	constructor( referenceKind,  reference) {
		this.reference = reference;

		for(var i=0;i<ReferenceKind.length;i++) {
            var refKind=ReferenceKind[i]
			if(i== referenceKind) {
				this.referenceKind = refKind;
				return  this;
			}
		}
		this.referenceKind = ReferenceKind[1];
	}
}
class ConstantRef {
    constructor(  constClass,  nameAndType ) {
        this.constClass = constClass;
        this.nameAndType = nameAndType;
    }
}
class ConstantFieldRef extends ConstantRef {

    constructor(constClass,nameAndType ) {
        super( constClass, nameAndType );
    }

}
class ConstantClass {

    constructor(name ) {
        this.name = name;
    }
}

class ConstantInterfaceMethodRef extends ConstantRef {

     constructor( constClass,  nameAndType ) {
        super( constClass, nameAndType );
    }
}

class ConstantMethodRef extends ConstantRef {

    constructor( constClass,  nameAndType ) {
       super( constClass, nameAndType );
   }
}
class AttributeInfo {
    constructor(input, constantPool,offset ) {
		this.name = String(constantPool[input.readUInt16BE(offset)]);
        offset+=2
        var atrlen=input.readUInt32BE(offset)
        offset+=4
		this.info = bufCopy(input,offset,offset+atrlen) //new byte[input.readInt()];
        offset+=atrlen
        this.newOffset=offset
		//input.readFully( this.info );
	}
}
class Attributes {

    /*private final AttributeInfo[]*/

    
    constructor(input,  constantPool,offset ){
        this.constantPool = constantPool;
        this.readAttributs=( input )=> {
            var attrs =[]// new AttributeInfo[];
            var len=input.readUInt16BE(offset);
            offset+=2
            for( var i = 0; i < len; i++ ) {
                attrs[i] = new AttributeInfo( input, constantPool,offset );
                offset=attrs[i].newOffset
            }
            return attrs;
        }
        this.attributes = this.readAttributs( input,offset );
        this.newOffset=offset
        this.get=( name) =>{
            if(name == null) {
                return null;
            }
            for( var attr in this.attributes ) {
                if( this.attributes[attr].name == name) {
                    return this.attributes[attr];
                }
            }
            return null;
        }
    }
}
class TryCatchFinally{
    constructor(input, constantPool,offset){
        this.start = input.readUInt16BE(offset);
        this.end = input.readUInt16BE(offset+2);
        this.handler = input.readUInt16BE(offset+4);
        this.type = constantPool[input.readUInt16BE(offset+6)];
    }
}
class FieldInfo{
    constructor( input=Buffer.from([]),offset,  constantPool)  {
        this.accessFlags = input.readUInt16BE(offset);
        this.faf= [new FieldsAccessFlag()]
        this.faf.pop()
        offset+=2
        this.constantPool = constantPool;

        for(var Enum in FieldsAccessFlag.enums) {
            var fieldAccessFlag=FieldsAccessFlag.enums[Enum]
            if((fieldAccessFlag & this.accessFlags) == fieldAccessFlag) {
                this.faf.push(fieldAccessFlag);
            }
        }

        this.name = String(constantPool[input.readUInt16BE(offset)]);
        this.description = String(constantPool[input.readUInt16BE(offset+2)]);
        offset+=4
        this.attributes = new Attributes( input, constantPool,offset );
        //this.description = String(constantPool.get( input.readUnsignedShort() ));
        this.newOffset=this.attributes.newOffset
    }
}
class MethodInfo{
    constructor( input, constantPool, offset) {
        this.accessFlags = input.readUInt16BE(offset)
        this.methodAccessFlags=[]
        offset+=2
        for(var Enum in MethodAccessFlag.enums) {
            var methodAccessFlag=MethodAccessFlag.enums[Enum]
            if((methodAccessFlag & this.accessFlags) == methodAccessFlag) {
                this.methodAccessFlags.push(methodAccessFlag);
            }
        }

        this.name = String(constantPool[input.readUInt16BE(offset)]);
        offset+=2
        this.description = String(constantPool[input.readUInt16BE(offset)]);
        offset+=2
        this.constantPool = constantPool;
        this.attributes = new Attributes( input, constantPool,offset );
        /**
         * @type Buffer
         */
        this.CodeAttr=this.attributes.get("Code").info
        this.getAdvanced=()=>{
            var CodeAttrBuf=this.CodeAttr
            var loffset=0
            
            var adv={}
            adv.maxStack=CodeAttrBuf.readUint16BE(loffset)
            adv.max_locals=CodeAttrBuf.readUint16BE(loffset+2)
            loffset+=4
            var bytecodelen=CodeAttrBuf.readUInt32BE(loffset)
            loffset+=4
            adv.bytecode=bufCopy(CodeAttrBuf,loffset,loffset+bytecodelen)
            loffset+=bytecodelen
            var extablelen=CodeAttrBuf.readUInt16BE(loffset)
            loffset+=2
            adv.extable=[]
            for (let i = 0; i < extablelen; i++) {
                adv.extable[i]=new TryCatchFinally(CodeAttrBuf,constantPool,loffset)
                loffset+=8
                
            }
            adv.attributes=new Attributes(CodeAttrBuf,constantPool,loffset)
            var localtblattr=adv.attributes.get("LocalVariableTable")
            if(localtblattr!=null){
                var localtblbuf=localtblattr.info
                var localtable=[]
                var sloffset=0
                var count=localtblbuf.readUInt16BE(sloffset)
                offset+=2
                for(var i=0;i<count;i++){
                    localtable.push({
                        spc:localtblbuf.readUInt16BE(sloffset),
                        len:localtblbuf.readUInt16BE(sloffset+2),
                        desc:constantPool[localtblbuf.readUInt16BE(sloffset+4)],
                        name:constantPool[localtblbuf.readUInt16BE(sloffset+6)],
                        ind:localtblbuf.readUInt16BE(sloffset+8)
                    })
                    sloffset+=10
                }

                adv.localtable={locals:localtable,raw:localtblbuf}
                //adv.locals=localtblbuf
            }
            loffset=adv.attributes.newOffset

            return adv

        }
        this.adv=this.getAdvanced()
        this.newOffset=this.attributes.newOffset
       // this.classFile = classFile;
    }
}
function n32tonum(bytes){
    var bits="0b"
    bytes.forEach(b=>{
      b= b.toString(2)
      while (b.length<8)b=0+b
      bits+=b})
    return bits-0
  }
  function bufCopy(buf,start,end){
    var buffarray=[]
    for(var i=start;i<end;i++)
      if(buf[i]!==undefined)
         buffarray.push(buf[i])
    return Buffer.from(buffarray)
  }
  
module.exports={

    ReferenceKind,
    ConstantClass,
    ConstantFieldRef,
    ConstantRef,
    ConstantInterfaceMethodRef,
    ConstantMethodRef,
    ConstantNameAndType,
    ConstantMethodHandle,
    ConstantMethodType,
    ConstantDynamic,
    ConstantInvokeDynamic,
    ClassAccessFlag,
    FieldsAccessFlag,
    FieldInfo,
    MethodInfo,
    n32tonum,
    bufCopy
    
}
UTILS=module.exports